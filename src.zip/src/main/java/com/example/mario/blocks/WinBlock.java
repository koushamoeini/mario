package com.example.mario.blocks;

public class WinBlock extends Block{
    public WinBlock( int edgeX, int edgeY, int blockX, int blockY) {
        super( edgeX, edgeY, blockX, blockY);
    }
}
