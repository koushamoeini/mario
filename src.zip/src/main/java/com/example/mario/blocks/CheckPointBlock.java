package com.example.mario.blocks;

public class CheckPointBlock {
}
