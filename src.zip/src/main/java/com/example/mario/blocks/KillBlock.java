package com.example.mario.blocks;

public class KillBlock extends Block{
    public KillBlock( int edgeX, int edgeY, int blockX, int blockY) {
        super( edgeX, edgeY, blockX, blockY);
    }
}
